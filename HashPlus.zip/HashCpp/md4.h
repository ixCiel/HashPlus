#pragma once
void md4Plus(unsigned char* str, unsigned int str_length, unsigned char* md4str, long long md4times);