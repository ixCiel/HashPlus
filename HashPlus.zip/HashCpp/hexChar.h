#pragma once
static const char* hexChar = "0123456789abcdef";