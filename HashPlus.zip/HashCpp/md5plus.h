#pragma once

void md5Plus(unsigned char* str, unsigned int str_length, unsigned char* md5str, long long md5times);